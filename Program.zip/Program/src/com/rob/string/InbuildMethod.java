package com.rob.string;

public class InbuildMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
