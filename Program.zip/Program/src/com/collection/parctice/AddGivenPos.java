package com.collection.parctice;

public class AddGivenPos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="hee heee haa haa";
		
	}

}
