package com.lumendata.test;

public class Test3 {
	public static void main(String[] args) {
		int x=0;
		assert(x>0);
		System.out.println("Fin");
	}

}
