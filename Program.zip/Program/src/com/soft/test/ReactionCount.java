package com.soft.test;

import java.util.HashMap;

public class ReactionCount {
	public static String findChar(String str) {
		//H2O
		HashMap<String, Integer> hashMap=new HashMap<String, Integer>();
		char[] ch=str.toCharArray();
		int i=0;
		while(ch.length>i) {
		String res="";
		int value=0;
		if(ch[i]>=65&&ch[i]<=91) {
			res+=ch[i];
			i++;
			if((i<ch.length&&ch[i]>=97&&ch[i]<=121)) {
				res+=ch[i];
				i++;	
			}
			if(hashMap.containsKey(res)) {
				value=hashMap.get(res);
				//System.out.println(value);
			}
			
			
			if(i<ch.length&&ch[i]>=48&&ch[i]<=57) {
				
				value=ch[i]-'0';
				//System.out.println(value);
				
			}else {
				value++;
			}
			
			
		}
		hashMap.put(res, value);
		i++;
		}
		System.out.println(hashMap.entrySet());
			
			
			
			
			
			
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		findChar("H1OHF");
	}

}
