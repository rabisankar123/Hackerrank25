package com.soft.test;

public class ItaratorDemo {

	public static void main(String[] args) {
		

	}

}
