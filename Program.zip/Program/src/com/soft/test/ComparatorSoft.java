package com.soft.test;

import java.util.Comparator;

class SortDec {

	String name;
	int value;
	public SortDec(String name, int value) {
		this.name=name;
		this.value=value;
	}
	
	
}

public class ComparatorSoft {

	public static void main(String[] args) {
		

	}

}
