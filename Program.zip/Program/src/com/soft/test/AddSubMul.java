package com.soft.test;

public class AddSubMul {
	public static int Sub(int a) {
		int add=a-10;
		return add;
	}
	public static int Mul(int a, int b) {
		int add=Sub(a);
		return add*b;
	}
public static int add(int a, int b) {
	int add=Mul(a,b);
	return add;
}
public static void main(String[] args) {
	int sum=add(5,6);
	System.out.println(sum);
}
}
