package com.soft.test;
class A{
	public int i;
	protected int j;
}

class B extends A{
	int j;
	public void display() {
		super.j=3;
		System.out.println(i+""+j);
	}
}
public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b=new B();
		b.i=1;
		//b.j=2;
		b.display();

	}

}
