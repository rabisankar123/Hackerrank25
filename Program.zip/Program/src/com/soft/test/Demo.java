package com.soft.test;

import java.util.ArrayList;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(1);
		al.add(2);
		int n=3;
		if(n<al.size())
		System.out.println(al.get(3));
	}

}
