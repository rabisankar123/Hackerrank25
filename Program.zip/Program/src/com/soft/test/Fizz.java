package com.soft.test;

public class Fizz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i <= 15; i++) {
			if(i%15==0) 
				System.out.println("FizzBuzz-"+i);
			if(i%5==0) 
				System.out.println("Buzz-"+i);
			if(i%3==0) 
				System.out.println("Fizz-"+i);
		}

	}

}
