package com.soft.test;

public class ConLoop {
	public static void find(boolean a) {
		if(!a) {
			System.out.println("hi");
		}else {
			System.out.println("hello");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		find(true);
	}

}
