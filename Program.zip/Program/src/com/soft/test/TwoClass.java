package com.soft.test;
class One{
	static int a=10;
	One(int b){
		System.out.println(a*b);
		a--;
		System.out.println(a*b);
	}
}

public class TwoClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		One a=new One(2);
		One v=new One(2);
		One e=new One(2);
		
	}

}
