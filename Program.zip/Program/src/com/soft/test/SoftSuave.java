package com.soft.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class SoftSuave {
	public static void findMember(ArrayList al) {
		HashMap<String, Integer> map=new HashMap<String, Integer>();
		//System.out.println(al);
		int i=0;
		while(al.size()>i) {
		String key=(String) al.get(i++);
		int value=((Integer)al.get(i++)/(Integer)al.get(i));
		
		map.put( key,value);
		i++;
	}
		int max=Collections.max(map.values());
		Set<String> s=map.keySet();
		Iterator<String> ita=s.iterator();
		while(ita.hasNext()) {
			String st=ita.next();
			//System.out.println(map.get(st));
			if(max==map.get(st))
			{
				System.out.println(st);
				break;
			}
		}
		//System.out.println(max);
		//System.out.println(map.entrySet());
		//   if(max==map.)
	}

	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter how many customer :");
		int n=scanner.nextInt();
		for (int i = 0; i <n; i++) {
			al.add(scanner.next());
			al.add(scanner.nextInt());
			al.add(scanner.nextInt());	
		}
		findMember(al);
	}

}
