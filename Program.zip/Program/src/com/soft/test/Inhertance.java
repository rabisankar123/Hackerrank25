package com.soft.test;
class Parent{
	public void callParent() {
		System.out.println("parent class");
	}
	
}
class Subclas extends Parent{
	public void callSubclass() {
		super.callParent();
	}
	
}

public class Inhertance {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Subclas p=new Subclas();
		p.callSubclass();
	}

}
