package com.soft.test;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="hello";
		String str1="java";
		String str2="hello";

	}

}
