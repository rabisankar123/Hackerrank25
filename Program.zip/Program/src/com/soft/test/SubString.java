package com.soft.test;

public class SubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello java";
		System.out.println(s.substring(4,10));
		System.out.println(s.indexOf("a"));
		System.out.println(s.lastIndexOf('a'));
		System.out.println(new StringBuffer(s).reverse().toString());
	}

}
