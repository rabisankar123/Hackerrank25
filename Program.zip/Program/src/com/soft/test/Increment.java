package com.soft.test;

public class Increment {
	static int i=5;
	static {
		System.out.println(i--);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println(10*--i);
		System.out.println(10*i++);

	}

}
