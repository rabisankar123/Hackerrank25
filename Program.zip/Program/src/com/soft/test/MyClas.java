package com.soft.test;



class Abc{
	 static int myValue=8;
	int superValue=0;
	public void show(int a) {
		superValue=a;
		
	}
}
public class MyClas {
	public static void main(String[] args) {
		Abc a=new Abc();
		a.myValue--;
		a.superValue=a.myValue+a.superValue;
		Abc b=new Abc();
		//b.myValue--;
		b.superValue=a.myValue+a.superValue;
		System.out.println("Class a "+a.myValue);
		System.out.println("Class b "+b.myValue);
	}

}
