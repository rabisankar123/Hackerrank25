package com.soft.test;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListDemo {
	 public static void main(String[] args) {
	        Scanner in=new Scanner(System.in);
	        ArrayList<ArrayList> list=new ArrayList<ArrayList>();
	        int n=in.nextInt();
	        for(int i=0;i<n;i++){
	            ArrayList<Integer> al=new ArrayList<Integer>();
	            int d=in.nextInt(); 
	             for(int j=0;j<d;j++){
	                al.add(in.nextInt());
	             }
	            list.add(al);
	        }
	        int q=in.nextInt();
	        for(int i=0;i<q;i++){
	            int x=in.nextInt();
	            int y=in.nextInt();
	            ArrayList<Integer> res=list.get(x-1);
	           try {
	            	System.out.println(res.get(y));
	            }catch(Exception e) {
	            	System.out.println("ERROR!");
	            }
	        }
	    }

}
