package com.soft.test;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] =new int[10];
		for (int i = 0; i < 10; i++) {
			arr[i]=i/2;
			arr[i]++;
			System.out.println(arr[i]);
			i++;
		}

	}

}
