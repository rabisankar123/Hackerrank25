package com.soft.test;

class Ab{
	int i;
	public void display() {
		System.out.println(i);
	}
}
class Bed extends Ab{
	int j;
	public void display() {
		System.out.println(j);
	}
}
public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bed b=new Bed();
		b.i=1;
		b.j=2;
		Ab r;
		r=b;
		r.display();
	}

}
