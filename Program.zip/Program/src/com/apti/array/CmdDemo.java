package com.apti.array;

public class CmdDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String s1[]=new String[3];
		s1[0]="java";
		s1[1]="sql";
		s1[2]="data";*/
		for (int i = 0; i < args.length; i++) {
			System.out.println("args["+i+"]="+args[i]);
		}

	}

}
