package com.apti.array;

import java.util.Scanner;

public class ArrayAddition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] arr=new int[3][3];
		Scanner sc=new Scanner(System.in);
		
	}

}
