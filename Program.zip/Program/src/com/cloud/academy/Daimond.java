package com.cloud.academy;

public class Daimond {
public static void main(String[] args) {
	int n=7;
	for (int row = 0; row < n; row++) {
		for (int sp = 0; sp < n-1-row; sp++) {
			System.out.print("  ");
		}
		for (int star = 0; star <= 2*row; star++) {
			System.out.print("* ");
		}
		System.out.println();
	}
	for (int row = 0; row < n; row++) {
		for (int sp = 0; sp < row; sp++) {
			System.out.print("  ");
		}
		for (int star = 0; star <=2*(n-1-row); star++) {
			System.out.print("* ");
		}
		System.out.println();
	}
}
}
