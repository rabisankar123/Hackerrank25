package com.cloud.academy;

public class DwnPiramid {
public static void main(String[] args) {
	int n=7;
	for (int rows = 0; rows < n; rows++) {
		for (int space = 0; space <rows; space++) {
		
		System.out.print("  ");
	}
		for (int star = 0; 2*(n-1-rows)>=star ; star++) {
			System.out.print("* ");
		}
		System.out.println();
}
	
}
}
