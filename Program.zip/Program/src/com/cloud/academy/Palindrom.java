package com.cloud.academy;

import java.util.Scanner;

public class Palindrom {
public static void main(String[] args) {
	System.out.println("Enter the no :");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int temp=n;
	int res = 0;
	while(n>0) {
		res=(res*10+(n%10));
		n=n/10;
	}
	System.out.println(res+" "+temp);
	if(res==temp) {
		System.out.println("panlidrom");
	}else {
		System.out.println("no panlidrom");
	}
}
}
