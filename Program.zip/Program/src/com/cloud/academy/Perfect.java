package com.cloud.academy;

import java.util.Scanner;

public class Perfect {
	public static boolean findPerfect(int num) {
		int temp=0;
		int i=1;
		while(i<num) {
			if(num%i==0) {
			temp+=i;
			}
			i++;
		}
		System.out.println(temp);
		if(num==temp)return true;
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a no:");
		boolean b=findPerfect(sc.nextInt());
		if(b) {
			System.out.println("Perfect No");
		}else {
			System.out.println("Not a perfect no");
		}
	}

}
