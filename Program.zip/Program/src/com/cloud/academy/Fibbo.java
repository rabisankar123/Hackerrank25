package com.cloud.academy;

import java.util.Scanner;

public class Fibbo {
public static void main(String[] args) {
	System.out.println("Enter series limit :");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int a=0,b=1,c;System.out.println(b);
	for (int i = 0; i < n; i++) {
		c=a+b;
		a=b;
		b=c;
		
		System.out.println(c);
	}
}
}
