package com.collention.practice;

import java.util.TreeSet;

public class TreeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet t=new TreeSet();
		/*t.add("A");
		t.add("a");*/
		t.add(null);
		/*t.add("L");*/
		System.out.println(t);
		
	}

}
