package com.jsp.regx;

import java.util.regex.*;

public class Regx {

	public static void main(String[] args) {
		
	}

}
