package com.jsp.apti;

public class MainClass3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] arr=new char[10][10];
		for(int i=2;i<10;i++)
		{
			for(int j=2;j<10;j++)
			{
				if(i%2==0)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
				
			}
			System.out.println();
			
		}
		

	}

}
