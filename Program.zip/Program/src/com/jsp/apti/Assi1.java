package com.jsp.apti;

public class Assi1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="TeamA 10 TeamB 12";
		String str1=new String();
		String str2=new String();
		char[] ch=s.toCharArray();
		int len=ch.length;
		int mid=len/2;
		
		for (int i = 0; i <mid; i++) {
			if(ch[i]=='0'||ch[i]=='1'||ch[i]=='2') {
			str1=str1+ch[i];			
			}
		}
		for (int i = mid; i <len; i++) {
			if(ch[i]=='0'||ch[i]=='1'||ch[i]=='2') {
			str2=str2+ch[i];				
			}
		}
		System.out.println("Score of TeamA : "+str1);
		System.out.println("Score of TeamB : "+str2);
		int x1=Integer.parseInt(str1);
		int x2=Integer.parseInt(str2);
		if(x1>x2)
		{
			System.out.println("TeamA win!");
		}
		else
		{
			System.out.println("TeamB win!");
		}
		
	}

}
