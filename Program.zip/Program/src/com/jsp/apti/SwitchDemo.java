package com.jsp.apti;

public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean con=false;
		if(con=true)
		{
			System.out.println("U r Programmer");
		}
		else
		{
			System.out.println("U r developer");
		}
	}

}
