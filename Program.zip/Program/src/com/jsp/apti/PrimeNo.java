package com.jsp.apti;

import java.util.Scanner;

public class PrimeNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=13;
			int d=num/2;
			while(num>1)
			{
			if(num%d==0)
			{
				d--;
				System.out.println();
				break;
			}
			
			}
		
		

	}

}
