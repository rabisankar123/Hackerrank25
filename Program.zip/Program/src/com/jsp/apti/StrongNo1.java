package com.jsp.apti;
import java.util.Scanner;

public class StrongNo1 {
	public static boolean isStrong(int num)
	{
		int temp=num;
		int res=0;
		while(num>0)
		{
			int rem=num%10;
			res=res+isFact(rem);
			num=num/10;
		}
		
		if(temp==res)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public static int isFact(int num)
	{
		int fact=1;
		while(num>0)
		{
			fact=fact*num;
			num--;
		}
		return fact;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main Started");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no:");
		int num=sc.nextInt();
		boolean res=isStrong(num);
		if(res==true)
		{
			System.out.println("Number is Strong");
		}
		else
		{
			System.out.println("Number is not Strong");	
		}
	}
	

}
