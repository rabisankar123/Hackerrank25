package com.jsp.apti;

public class MainClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] arr=new char[10][10];
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				arr[i][j]='*';
				System.out.print(arr[i][j]);
				
			}
			System.out.println();
			
		}
		
		
	}

}
