package com.jsp.apti;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program Strated");
		int binary=0b11;
		int octal=0467;
		int hexa=0xa;
		System.out.println("Binary : "+binary+"\nOctal : "+octal+"\nHexa : "+hexa);
		System.out.println("Program Ends");
	}

}
