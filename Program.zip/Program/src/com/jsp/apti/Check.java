package com.jsp.apti;

public class Check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		for (int i = 0; i < 5; i++) {
			if(i==4)
				System.out.print(a);	
			else
				System.out.println(a);	
		}
		for (int i = 0; i < 5; i++) {
			System.out.print(b);	
		}
		
		System.out.print(b);
	}

}
