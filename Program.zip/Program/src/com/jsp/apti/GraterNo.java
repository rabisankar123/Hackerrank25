package com.jsp.apti;

public class GraterNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=6,b=5,c=9;
		String s=a>b&&a>c?"a is Grater":b>c?"b is Grater":"c is Grater";
		System.out.println(s);

	}

}
