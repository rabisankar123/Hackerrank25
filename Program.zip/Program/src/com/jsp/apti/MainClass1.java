package com.jsp.apti;

public class MainClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k=5;
		for(int i=0;i<5;i++)
		{
			for(int j=5;j>=2;j--)
			{
				System.out.print(" "+k);
			}
			System.out.println("");
			k--;
		}
	}

}
