package com.jsp.number;

import java.util.Scanner;

public class D2H {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			System.out.println("Enter the number :");
			Scanner sc=new Scanner(System.in);
			int num=sc.nextInt();
			String s="";
			while(num>0)
			{
				int rem=num%16;
				
				if(rem>9)
				{
					int d=rem-10;
					char ch=(char) (65+d);
					s=s+ch;
					num=num/16;
				}
				else {
				s=s+rem;
				num=num/16;
				}
				
				
			}
			 
			char ch[]=s.toCharArray();
			String str="";
			for (int i = ch.length-1; i >=0; i--) {
				str+=ch[i];
			}
			System.out.println(str);
		}


}
