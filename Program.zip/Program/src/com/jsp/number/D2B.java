package com.jsp.number;

import java.util.Scanner;
/*
 * 13/2=6
 * 13%2=1
 * 
 */

public class D2B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number :");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		String s="";
		while(num>0)
		{
			if(num%2==0)
			{
				s=s+0;
				num=num/2;
			}
			else
			{
				s=s+1;
				num=num/2;
			}
		}
		System.out.println(s);
	}

}
