package com.jsp.number;

import java.util.Scanner;

public class H2D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s;
		int len = 0;
		int res = 0;
		int count=0;
		System.out.println("Enter the number :");
		Scanner sc=new Scanner(System.in);
		s=sc.next();
		len=s.length()-1;
		
		
		//System.out.println(ch);
		while(len>=0)
		{
		
			int ch=s.charAt(len);
			//System.out.println(ch);
			len--;
		if(ch>=65&&ch<=70||ch>=97&&ch<=102||ch>=48&&ch<=58)
		{
			res=res+(ch-55)*pow(16,count++);
			
		}
		}
		System.out.println(res);
		

	}
	private static int pow(int num, int pwr) {
		int res=1;
		for (int i = 0; i < pwr; i++) {
			
			res=res*num;
		}
		return res;
	}

}
