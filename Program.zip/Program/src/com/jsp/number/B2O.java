package com.jsp.number;

public class B2O {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	public static boolean isBinary(int num)
	{
		while(num>0)
		{
			int rem=num%10;
			if(rem>1)
			{
				return false;
			}
			num=num/10;
		}
		return true;
	}
	private static int pow(int num, int pwr) {
		int res=1;
		for (int i = 0; i < pwr; i++) {
			
			res=res*num;
		}
		return res;
	}

}
