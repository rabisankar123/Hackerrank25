package com.jsp.number;

import java.util.Scanner;

public class D2O {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			System.out.println("Enter the number :");
			Scanner sc=new Scanner(System.in);
			int num=sc.nextInt();
			String s="";
			while(num>0)
			{
				int rem=num%8;
				
				s=s+rem;
				num=num/8;
				
			}
			 
			char ch[]=s.toCharArray();
			String str="";
			for (int i = ch.length-1; i >=0; i--) {
				str+=ch[i];
			}
			System.out.println(str);
		}

	

}
