package com.jsp.number;

import java.util.Scanner;
//octal to decimal																																																																																																																																																																																																																																																																																																																																																																																						
public class O2D {
	
		public static boolean isOctal(int num)
		{
			while(num>0)
			{
				int rem=num%10;
				if(rem>7)
				{
					return false;
				}
				num=num/10;
			}
			return true;
				}
		private static int pow(int num, int pwr) {
			int res=1;
			for (int i = 0; i < pwr; i++) {
				
				res=res*num;
			}
			return res;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		System.out.println("Enter the number :");
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		boolean b1=isOctal(num);
		if(b1==true)
		{
		int count=0;
		int res=0;
		while(num>0)
		{
			int rem=num%10;
			res=res+(rem*pow(8,count++));
			num=num/10;
		}
		System.out.println(res);
		}
		else
		{
			System.out.println("Invaild no");
		}

	}

	}

